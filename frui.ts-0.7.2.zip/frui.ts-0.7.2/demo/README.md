# `stories`

> TODO: description

## Usage

```
const stories = require('stories');

// TODO: DEMONSTRATE API
```
