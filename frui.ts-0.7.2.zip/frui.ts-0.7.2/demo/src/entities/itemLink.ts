// tslint:disable-next-line: interface-name
export interface ItemLink {
  id: number;
  name: string;
}
