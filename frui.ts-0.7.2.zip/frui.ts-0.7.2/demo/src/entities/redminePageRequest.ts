export interface IRedminePageRequest {
  offset?: number;
  limit?: number;
  sort?: string;
  include?: string;
}
