export interface IRedminePageInfo {
  total_count: number;
  offset: number;
  limit: number;
}
