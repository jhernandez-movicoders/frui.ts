import { ScreenBase } from "@frui.ts/screens";

export default class IssueDetailViewModel extends ScreenBase {
  isCreating: boolean;
  isEditing: boolean;
}
