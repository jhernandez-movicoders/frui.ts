export default function _default(url: any, ...args: any[]): any;
