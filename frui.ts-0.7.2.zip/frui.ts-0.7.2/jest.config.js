module.exports = {
  preset: 'ts-jest',
  modulePathIgnorePatterns: [
    'mocks/'
  ]
};
