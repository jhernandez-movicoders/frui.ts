# `bootstrap`

Bootstrap controls ready for Frui.ts integration. Mainly input controls wrapped in `BindingComponent`.

## Input

```
TODO
```

## Select

```
TODO
```

## Check

```
TODO
```
