export interface CommonInputProps {
  placeholder?: string;
  noValidation?: boolean;
  errorMessage?: string;
}
