export enum SortingDirection {
  Ascending = 1,
  Descending = -1,
}
